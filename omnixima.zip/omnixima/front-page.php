<?php
/**
 * Front Page Template
 *
 * @package omnixima
 */
get_header();
?>

<div class="container">
    <h2>Front Page</h2>
</div>



<?php get_footer();?>