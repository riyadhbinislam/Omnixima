<?php
/**
 *  Blog Entry-Meta Template
 *
 * @package omnixima
 */
?>

<div class="entrry-meta mb-3">
    <?php
        omnixima_posted_on();
        omnixima_posted_by();
    ?>
</div>