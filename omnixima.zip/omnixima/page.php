<?php
/**
 *  Page Template
 *
 * @package omnixima
 */
get_header();
?>

<div class="container">
    <h3>Page</h3>
</div>



<?php get_footer();?>